﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PasswordMaker
{

    /// <summary>
    /// File created: 12/11/2016
    /// Last modified: 12/13/2016
    /// Modified by: gameCreator94
    /// Interaction logic for UserMenu.xaml
    /// This is the welcome menu where users choose to add new account information, run programs, and delete informaation.
    /// </summary>
    public partial class UserMenu : Window
    {

        int lengthOfPassword = 0;
        int randomNumber = 0;
        Random random = new Random();
        string numberString = "1234567890";
        string upperCaseString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        string lowerCaseString = "abcdefghijklmnopqrstuvwxyz";
        string symbolString = "!!@#$%^&*()<>?:{}|_+-_=+,./\\\"";
        string outputString = "";
        
        public UserMenu()
        {

            InitializeComponent();

        }// public UserMenu()

        /// <summary>
        /// Method created: 12/13/2016
        /// Last modified: 12/13/2016
        /// Modified by: gameCreator94
        /// Sets the main menu buttons to invisible and gives the user the choice 
        /// of either adding programs from their computer or from online accounts.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Add_Button_Click(object sender, RoutedEventArgs e)
        {

        }// private void Add_Button_Click(object sender, RoutedEventArgs e)

        /// <summary>
        /// Method created: 12/13/2016
        /// Last modified: 12/13/2016
        /// Modified by: gameCreator94
        /// Sets the main menu buttons to invisible and brings up all of the
        /// choices that have been added by the user.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Run_Button_Click(object sender, RoutedEventArgs e)
        {

        }// private void Run_Button_Click(object sender, RoutedEventArgs e)

        /// <summary>
        /// Method created: 12/13/2016
        /// Last modified: 12/13/2016
        /// Modified by: gameCreator94
        /// Sets the main menu buttons to invisible and brings up all of the
        /// choices that have been added by the user allowing them to
        /// select them to be deleted.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Delete_Button_Click(object sender, RoutedEventArgs e)
        {

        }// private void Delete_Button_Click(object sender, RoutedEventArgs e)

        /// <summary>
        /// Method created: 12/18/2016
        /// Last modified: 1/23/2017
        /// Modified by: gameCreator94
        /// Randomly generates a password based on the characters that 
        /// the generator has access to.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Make_Password_Button_Click(object sender, RoutedEventArgs e)
        {

            string contentString = "";
            outputString = "";
            if(Number_CheckBox.IsChecked == true)
            {

                contentString = contentString + numberString;

            }// if(Number_CheckBox.IsChecked == true)
            if(Upper_Case_CheckBox.IsChecked == true)
            {

                contentString = contentString + upperCaseString;

            }// if(Upper_Case_CheckBox.IsChecked == true).IsChecked == true)
            if(Lower_Case_CheckBox.IsChecked == true)
            {

                contentString = contentString + lowerCaseString;

            }// if(Lower_Case_CheckBox.IsChecked == true)
            if(Symbol_CheckBox.IsChecked == true)
            {

                contentString = contentString + symbolString;

            }// if(Symbol_CheckBox.IsChecked == true)
            string tempString = "";
            Password_Generation_TextBox.Clear();
            tempString = Password_Length_ComboBox.Text;
            lengthOfPassword = Int32.Parse(tempString);
            if (contentString.Length >= 10)
            {

                for (int counter = 0; counter < lengthOfPassword; counter++)
                {

                    randomNumber = random.Next(0, contentString.Length);
                    outputString = outputString + contentString.Substring(randomNumber, 1);

                }// for(int counter = 0; counter < lengthOfPassword; counter++)

            }// if (contentString.Length >= 10)
            Password_Generation_TextBox.Text = outputString;

        }// private void Make_Password_Button_Click(object sender, RoutedEventArgs e)

        /// <summary>
        /// Method created: 12/18/2016
        /// Last modified: 12/18/2016
        /// Modified by: gameCreator94
        /// Populates the Password_Length_Combox.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Password_Length_ComboBox_Initialized(object sender, EventArgs e)
        {

            for(int counter = 1; counter < 17; counter++)
            {

                Password_Length_ComboBox.Items.Add(8 * counter);

            }// for(int counter = 0; counter < 17; counter++)
            Password_Length_ComboBox.SelectedIndex = 2;

        }// private void Password_Length_ComboBox_Initialized(object sender, EventArgs e)

    }// public partial class UserMenu : Window

}// namespace PasswordMaker
