﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PasswordMaker
{

    /// <summary>
    /// File created: 12/14/2016
    /// Last modified: 12/14/2016
    /// Interaction logic for MainWindow.xaml
    /// This is the welcome menu where users choose to add new account information, run programs, and delete informaation.
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {

            InitializeComponent();

        }// public MainWindow()

        /// <summary>
        /// Method created: 12/14/2016
        /// Last modified: 12/14/2016
        /// Checks to see if the username links to a database already created.
        /// Then it checks to see if the password is valid to access the
        /// chosen database.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Sign_In_Button_Click(object sender, RoutedEventArgs e)
        {

            UserMenu userMenu = new UserMenu();
            userMenu.Show();
            this.Close();

        }// private void Sign_In_Button_Click(object sender, RoutedEventArgs e)

        /// <summary>
        /// Method created: 12/14/2016
        /// Last modified: 12/14/2016
        /// Prompts user to make new account if they have not created one
        /// before by asking them to create a username and password for
        /// the account.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Create_Account_Button_Click(object sender, RoutedEventArgs e)
        {

        }// private void Create_Account_Button_Click(object sender, RoutedEventArgs e)

    }// public partial class MainWindow : Window

}// namespace PasswordMaker
