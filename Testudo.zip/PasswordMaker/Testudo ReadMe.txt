Testudo password manager


Description:
Testudo is a open source password manager that was started for the purpose of helping people build their skills in software engineering and to help
with resume building.

Goal:
The goal of Testudo is to create a password manager that a person can use store usernames and passwords not only for online programs such as email,
but also for offline programs that don't require going online to use.


Goals:
(In descending order of priority)
Setup Testudo with database and create hash function for database
Add UI for creating account
Change UI design for sign in and welcome screens
(The next parts fairly ambitious part and will only be started on once the other parts are completed)
Setup a server to allow for use online as well and allow people to access the passwords on other computers.
Add virtual section to Testudo that allows people to check downloads for ransomware

Commenting Style:
The style of the comments in the C# files should in done in the following manner:
When creating a new file.
/// <summary>
/// File created: Date
/// Last modified: Date
/// Modified by: GitHub username (add name each time you make a change).
/// Description of the file.
/// Description of the file.
/// </summary>
When creating a new method.
/// <summary>
/// Method created: Date
/// Last modified: Date
/// Modified by: GitHub username (add name each time you make a change).
/// Description of the Method.
/// Description of the Method.
/// </summary>
(This following are done by the visual studios software).
/// <param name="sender"></param>
/// <param name="e"></param>